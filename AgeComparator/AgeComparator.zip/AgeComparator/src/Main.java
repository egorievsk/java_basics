public class Main {
    public static void main(String[] args) {
        int vasyaAge = 120;
        int katyaAge = 18;
        int mishaAge = 120;

        int min = -1; // минимальный возраст
        int middle = -1; // средний возраст
        int max = -1; // максимальный возраст

        //max age
        if (vasyaAge >= katyaAge && vasyaAge >= mishaAge) {
            max = vasyaAge;
        }else if (katyaAge >= vasyaAge && katyaAge >= mishaAge ) {
            max = katyaAge;
        } else if (mishaAge >= vasyaAge && mishaAge >= katyaAge ) {
            max = mishaAge;
        }

        //middle
        if (vasyaAge >= katyaAge && vasyaAge <= mishaAge || vasyaAge >= mishaAge && vasyaAge <= katyaAge) {
            middle = vasyaAge;
        } else if (katyaAge >= vasyaAge && katyaAge <= mishaAge || katyaAge >= mishaAge && katyaAge <= vasyaAge) {
            middle = katyaAge;
        } else if (mishaAge >= vasyaAge && mishaAge <= katyaAge || mishaAge >= katyaAge && mishaAge <= vasyaAge) {
            middle = mishaAge;
        }

        //min
        if (vasyaAge <= middle && katyaAge >= middle && mishaAge >= middle) {
            min = vasyaAge;
        } else if (katyaAge <= middle && vasyaAge >= middle && mishaAge >= middle) {
            min = katyaAge;
        } else if (mishaAge <= middle && katyaAge >= middle && vasyaAge >= middle) {
            min = mishaAge;
        }

        System.out.println("Minimal age: " +  min);
        System.out.println("Middle age: " + middle);
        System.out.println("Maximal age: " + max);
    }
}