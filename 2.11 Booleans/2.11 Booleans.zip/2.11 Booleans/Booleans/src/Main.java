
public class Main {
    public static void main(String[] args) {
        int milkAmount = 400; // ml
        int powderAmount = 400; // g
        int eggsCount = 5; // items
        int sugarAmount = 10; // g
        int oilAmount = 30; // ml
        int appleCount = 5; // items

        /*
        Пример
         */
        // Example
        // apples - 5
        //if (appleCount >= 5) {
        //    System.out.println("Apple juice");
        //}

        boolean powderEnough = false;
        boolean sugarEnough = false;
        boolean milkEnough = false;
        boolean oilEnough = false;
        boolean eggsEnough = false;

        // powder - 400 g, sugar - 10 g, milk - 1 l, oil - 30 ml
        if (powderAmount >= 400)  {
            powderEnough = true;
        }
        if (sugarAmount >= 10) {
            sugarEnough = true;
        }
        if (milkAmount >= 1000) {
            milkEnough = true;
        }
        if (oilAmount >= 30) {
            oilEnough = true;
        }
        if (powderEnough && sugarEnough && milkEnough && oilEnough) {
            System.out.println("Pancakes");
        }

        powderEnough = false;
        sugarEnough = false;
        milkEnough = false;
        oilEnough = false;
        eggsEnough = false;

        // milk - 300 ml, powder - 5 g, eggs - 5
        if (milkAmount >= 300) {
            milkEnough = true;
        }
        if (powderAmount >= 5) {
            powderEnough = true;
        }
        if (eggsCount >= 5) {
            eggsEnough = true;
        }
        if (milkEnough && powderEnough && eggsEnough) {
            System.out.println("Omelette");
        }

        // apples - 3, milk - 100 ml, powder - 300 g, eggs - 4
        if (appleCount >=3 && milkAmount >= 100 && powderAmount >= 300 && eggsCount >=4) {
            System.out.println("Apple pie");
        }
    }
}